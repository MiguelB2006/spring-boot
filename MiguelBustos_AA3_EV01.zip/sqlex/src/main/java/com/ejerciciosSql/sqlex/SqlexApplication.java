package com.ejerciciosSql.sqlex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SqlexApplication {

	public static void main(String[] args) {
		SpringApplication.run(SqlexApplication.class, args);
	}

}
